import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import NavBar from '../../components/Navbar'
import api from '../../services/index'




interface AnimalProps {
	_id: string;
	category: string;
	name: string;
	code: number;
	description: string;
}
export default function ListAnimal() {
	const [animalsList, setAnimalsList] = useState<AnimalProps[]>([]);

	useEffect(() => {
		getAnimals();

	}, [])

	const getAnimals = async () => {
		const result = await api.get('/project');

		setAnimalsList(result.data);


	}


	return (
		<div className="flex flex-col">
			<NavBar />
			<h2 className="flex justify-start text-2xl ml-20 pt-8">List of Animals</h2>
			<div className="w-full h-full">

				<div className="grid min-h-screen place-items-center">
					<div className="w-11/12 p-12 bg-white sm:w-8/12 md:w-1/2 lg:w-11/12">
						<div className="w-full flex flex-col  justify-between">

							<div className="grid grid-cols-5 gap-2 border-b-2 select-none text-2xl">
								<p className="text-2xl">Name</p>
								<p className="text-2xl">Category</p>
								<p className="text-2xl">Code</p>
								<p className="text-2xl">Description</p>
							</div>

							{animalsList?.map((item) => {
								return (
									<div className="grid grid-cols-5 gap-2 hover:bg-gray-200 cursor-pointer">
										<p>{item.name}</p>
										<p>{item.category}</p>
										<p>{item.code}</p>
										<p>{item.description}</p>
										<Link to={{ pathname: `edit/${item._id}` }}><button className="mr-10 w-40 my-2 bg-teal-500 hover:bg-teal-700 hover:text-white">Update</button></Link>
									</div>
								)
							})}
						</div>
					</div>
				</div>

			</div>

		</div>
	);
}