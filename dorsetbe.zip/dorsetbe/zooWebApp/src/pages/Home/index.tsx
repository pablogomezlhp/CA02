import React from "react";
import { Link } from "react-router-dom";
import NavBar from '../../components/Navbar'
import Imagem from '../../assets/back.svg'

import "./styles.css";

export default function Zoo() {
  return (
    <>
		
      <div>
			<NavBar/>
        <div className="flex flex-row mt-2" id="top">
          <div className="flex w-1/2 justify-center items-center">
            <section className="flex flex-col justify-center items-center text-center" id="section-1">
              <h1 className="text-6xl w-full">Hello collaborator,</h1>
              <p className="text-2xl mt-2">Here you can manage information</p>
							 <p className="text-2xl ">about the animals that are in our Zoo</p>
              <Link to={"/animals"}>
                {" "}
                <button className="mt-10">CHECK THE ANIMALS LIST</button>{" "}
              </Link>
            </section>
          </div>
          <div className="w-1/2">
					<img src={Imagem} alt=""/>
					</div>
        </div>
      </div>
    </>
  );
}