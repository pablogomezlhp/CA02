import React, { useState, useCallback, ChangeEvent, FormEvent } from "react";
import api from '../../services/index'
import NavBar from '../../components/Navbar'
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";

// import ExerciseList from "../../components/create-exercise.component";

const AnimalFormSchema = Yup.object().shape({
	name: Yup.string()
		.required("name is required"),
	category: Yup.string().required("category is required"),
	code: Yup.string()
		.required("Code is required"),
	description: Yup.string()
		.required("descriptionis required"),
});
interface AnimalProps {
	category: string;
	name: string;
	code: number;
	description: string;
}
export default function InsertAnimal() {
	const [formData, setFormData] = useState({
		name: '',
		category: '',
		code: '',
		description: ''
	});

	function handleInputChange(event: ChangeEvent<HTMLInputElement>) {
		const { name, value } = event.target
		setFormData({ ...formData, [name]: value })
	}

	async function handleSubmit(event: FormEvent) {
		event.preventDefault()
		console.log('chegou')
		const { name, category, code, description } = formData;

		const data = {
			name,
			category,
			code, description
		};
		await api.post('/project/', data);
		alert('Animal created')
		// history.push('');
	}
	return (
		<>
			<NavBar />
			<div className="w-full">
			<h2 className="flex justify-start text-2xl ml-20 pt-8">New Animal</h2>
		
			</div>

			<div className="grid min-h-screen place-items-center">
				<div className="w-11/12 p-12 bg-white sm:w-8/12 md:w-1/2 lg:w-5/12">
					<h1 className="text-xl font-semibold">Hello there 👋, <span className="font-normal">please fill information about the new animal</span></h1>
					<form onSubmit={handleSubmit} className="mt-6">
						<div className="flex justify-between gap-3">
							<span className="w-1/2">
								<label htmlFor="name" className="block text-xs font-semibold text-gray-600 uppercase">Name</label>
								<input onChange={handleInputChange} type="text"
									name="name"
									id="name" placeholder="Bravo" className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner" required />
							</span>
							<span className="w-1/2">
								<label htmlFor="name" className="block text-xs font-semibold text-gray-600 uppercase">Category</label>
								<input type="text-area"
									name="category"
									id="category"
									onChange={handleInputChange} placeholder="Dog" className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner" required />
							</span>
						</div>
						<label htmlFor="code" className="block mt-2 text-xs font-semibold text-gray-600 uppercase">Code</label>
						<input type="text"
							name="code"
							id="code"
							onChange={handleInputChange} placeholder="097" className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner" required />
						<label htmlFor="description" className="block mt-2 text-xs font-semibold text-gray-600 uppercase">Description</label>
						<input type="text"
							name="description"
							id="description"
							onChange={handleInputChange} placeholder="nice dog" className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner" required />

						<button type="submit" className="w-full py-3 mt-6 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none">
							Create
      </button>

					</form>
				</div>
			</div>
		</>
	);
}