import React, { useEffect, useState, useCallback, ChangeEvent, FormEvent } from "react";
import { useParams } from 'react-router-dom'

import NavBar from '../../components/Navbar'
import api from '../../services/index'



interface MyAnimalValues {
	id?: string;
	model: string;
	vehicle_registration: string;
	color: string;
	year: string;
}
interface idProps {
	id: string
}

interface ModalAnimalProps {
	onConfirm: () => void;
	AnimalDetails?: MyAnimalValues;
}

const UpdateAnimal: React.FC<ModalAnimalProps> = ({ onConfirm, AnimalDetails }) => {
	const idResult: idProps = useParams();
	console.log(idResult)
	const [formData, setFormData] = useState({
		name: '',
		category: '',
		code: '',
		description: ''
	});


	function handleInputChange(event: ChangeEvent<HTMLInputElement>) {
		const { name, value } = event.target
		setFormData({ ...formData, [name]: value })
	}

	useEffect(() => {
		getAnimal();

	}, [])

	const getAnimal = async () => {
		const result = await api.get(`/project/${idResult.id}`);
		const animal = result.data
		setFormData({
			name: animal.name,
			category: animal.category,
			code: animal.code,
			description: animal.description
		})

	}
	async function handleSubmit(event: FormEvent) {
		event.preventDefault()

		const { name, category, code, description } = formData;

		const data = {
			name,
			category,
			code, description
		};
		try {
			await api.post('/project/', data);
			alert('Animal updated.')
			getAnimal();


		} catch (err) {
			alert('Animal cannot be uptdated.')
		}

	}


	return (
		<div className="flex flex-col">
			<NavBar />
			<h2 className="flex justify-start text-2xl ml-20 pt-8">Update Animal</h2>

			<div className="grid min-h-screen place-items-center">
				<div className="w-11/12 p-12 bg-white sm:w-8/12 md:w-1/2 lg:w-5/12">
					<h1 className="text-xl font-semibold">Hello there 👋, <span className="font-normal">please fill information about the new animal</span></h1>
					<form onSubmit={handleSubmit} className="mt-6">
						<div className="flex justify-between gap-3">
							<span className="w-1/2">
								<label htmlFor="name" className="block text-xs font-semibold text-gray-600 uppercase">Name</label>
								<input onChange={handleInputChange} type="text"
									name="name"
									id="name" placeholder={formData.name} value={formData.name} className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner" required />
							</span>
							<span className="w-1/2">
								<label htmlFor="name" className="block text-xs font-semibold text-gray-600 uppercase">Category</label>
								<input type="text-area"
									name="category"
									id="category"
									onChange={handleInputChange} value={formData.category} placeholder={formData.category} className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner" required />
							</span>
						</div>
						<label htmlFor="code" className="block mt-2 text-xs font-semibold text-gray-600 uppercase">Code</label>
						<input type="text"
							name="code"
							id="code"
							onChange={handleInputChange} placeholder={formData.code} value={formData.code} className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner" required />
						<label htmlFor="description" className="block mt-2 text-xs font-semibold text-gray-600 uppercase">Description</label>
						<input type="text"
							name="description"
							id="description"
							onChange={handleInputChange} placeholder={formData.description} value={formData.description} className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner" required />

						<button type="submit" className="py-3 mt-6 font-medium text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none">
							Update
      			</button>

					</form>
				</div>
			</div>
			<div id="thirdPage"></div>
		</div>
	);
}
export default UpdateAnimal;