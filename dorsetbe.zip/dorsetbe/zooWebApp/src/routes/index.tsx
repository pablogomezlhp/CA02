import React from "react";
import { BrowserRouter, Route, Switch } from 'react-router-dom';

// import Navbar from "./pages/Navbar"
import Home from "../pages/Home";
// import Exercises from "./pages/Exercises";
// import EditExercise from "./components/edit-exercise.component";
import InsertAnimal from "../pages/InsertAnimal";
import UpdateAnimal from "../pages/UpdateAnimal";
import ListAnimal from "../pages/ListAnimals";
import RemoveAnimal from "../pages/RemoveAnimal";



// import CreateUser from "./pages/User";

export default function Routes() {
  return (
<BrowserRouter>
{/* <Navbar /> */}
  <Switch>
    <Route path="/" exact component={Home} />
		<Route path="/create" component={InsertAnimal} />
    <Route path="/animals" component={ListAnimal} />
    <Route path="/edit/:id" component={UpdateAnimal} />
    <Route path="/remove" component={RemoveAnimal} />
  </Switch>
</BrowserRouter>
  );
}