/// <reference types="react-scripts" />
declare module 'reoverlay';