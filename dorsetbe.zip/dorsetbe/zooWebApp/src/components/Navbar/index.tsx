import React, { Component } from "react";
import { Link } from "react-router-dom";


export default class Navbar extends Component {
  render() {
    return (
      <>
        <nav className=" navbar-expand-lg">
          <div className=" navbar  collpase navbar-collapse">
            <ul className="flex flex-row justify-end navbar-nav mr-auto mt-10">
              <li className="font-semibold navbar-item">
                <Link to="/" className="nav-link">
                  Home
                </Link>
              </li>
              <li className="mx-10 font-semibold  navbar-item">
                <Link to="/animals" className="nav-link">
                  List Animals
                </Link>
              </li>
              <li className="font-semibold navbar-item">
                <Link to="/create" className="nav-link">
                  New Animal
                </Link>
              </li>
              
							<li className="mx-10  font-semibold navbar-item">
                <Link to="/remove" className="nav-link">
                  Remove Animal
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </>
    );
  }
}