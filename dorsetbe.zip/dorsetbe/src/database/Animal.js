const mongoose = require('mongoose');

const animal = new mongoose.Schema({
    name: {
        type: String,
        lowercase: true,
    },
    category: {
        type: String,
        lowercase: true
    },
    code: {
				type: Number,
				unique: true,
    },
    description: {
        type: String,
        lowercase: true
    }
});

module.exports = Animal = mongoose.model('animal', animal);