const express = require("express");
const mongoose = require("mongoose");
const Animal = require("../database/Animal");
const route = express.Router();

route.get("/", async(request, response) => {
    const results = await Animal.find();
    response.json(results);
});

route.get("/:id", async(request, response) => {
    const { id } = request.params;

    const results = await Animal.findById(id);
    response.json(results);
});

route.post("/", async(request, response) => {

    const { name, category,  code, description} = request.body;
    console.log('fname', name, 'secondname', category, 'mn', code, 'email', description)
    let animal = {};
    animal.name = name;
    animal.category = category;
    animal.code = code;
    animal.description = description;

    //This will check//allow if the information matches the requirement.
    let animalModel = new Animal(animal);

    //First of all we need to check if have any user using the same email, if have we need to return a msg.
    const checkIfAnimalExists = await Animal.findOne({ code: animal.code });
    // console.log("aqui", checkIfUserExists);
    if (!!checkIfAnimalExists) {
        return response.json({
            message: "This code is already used by other Animal",
        });
    }
    // if not then we ask to save the data into to the database.
    try {
        await animalModel.save();
    } catch (err) {
        return response.json({ message: "animal info canot be created" });
    }
    response.json(animalModel);
});
route.put("/:id", async(request, response) => {
    const { name, description } = request.body;
    const { id } = request.params;
    let animal = {};
    animal.name = name;
    animal.description = description;

    const filter = { _id: id };
    const update = { name: animal.name, description: animal.description };

    await Animal.findOneAndUpdate(filter, update, {
        returnOriginal: false,
    });


    response.json({ animal});
});



route.delete("/:id", async(request, response) => {
    const { id } = request.params;

    try {

        // looking for id and delete.
        await Animal.findByIdAndDelete(id);
    } catch (err) {
        return response.json({ message: 'animal cannot be deleted.' })
    }

    response.json({ message: "animal deleted" });
});

module.exports = route;